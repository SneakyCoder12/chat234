const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const chatBox = document.getElementById('chat-box');

function appendUser(msg){
  const d = document.createElement('div');
  d.className = 'user-msg'; d.innerText = msg; chatBox.appendChild(d); chatBox.scrollTop = chatBox.scrollHeight;
}
function appendBot(msg){
  const d = document.createElement('div');
  d.className = 'bot-msg'; d.innerText = msg; chatBox.appendChild(d); chatBox.scrollTop = chatBox.scrollHeight;
}

chatForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const userMessage = chatInput.value.trim();
  if(!userMessage) return;
  appendUser(userMessage);
  chatInput.value='';
  try{
    const resp = await fetch('/api/chat',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({user_id:'testuser', message: userMessage})
    });
    if(!resp.ok){
      const err = await resp.text();
      appendBot('Server error: '+err);
      return;
    }
    const data = await resp.json();
    const out = data.answer || data.reply || (data.intent && data.answer ? data.answer : JSON.stringify(data));
    appendBot(out);
  }catch(e){
    appendBot('Network error: '+e.message);
  }
});
