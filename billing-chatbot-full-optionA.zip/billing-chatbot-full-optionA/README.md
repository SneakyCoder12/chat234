Billing Chatbot POC - Full Option A

This package contains a full demo POC:
 - FastAPI backend (backend/main.py)
 - Lightweight LangGraph-style orchestrator (backend/langgraph/...)
 - Gemini client wrapper (backend/utils/gemini_client.py)
 - Simple RAG indexing from markdown files (backend/rag/*.md)
 - Vector store persisted at backend/rag/vectors.json (built automatically)
 - Frontend static UI served at / (index.html)

Quick start (Windows):
1. Extract the zip and open terminal in backend/ folder
2. Create and activate venv:
   python -m venv .venv
   .venv\Scripts\activate
3. Install dependencies:
   pip install -r requirements.txt
4. Put your Gemini API key into backend/.env as:
   GOOGLE_API_KEY=YOUR_KEY_HERE
5. Run server:
   uvicorn main:app --reload --port 8000
6. Open http://127.0.0.1:8000

Notes:
- If you don't set GOOGLE_API_KEY, the app runs in mock mode (no external API calls),
  so you can demo functionality without using Gemini during interviews.
- The gemini client uses google.generativeai SDK; if you prefer direct REST, replace gemini_client accordingly.
