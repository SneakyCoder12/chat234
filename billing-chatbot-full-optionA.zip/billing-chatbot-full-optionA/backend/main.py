import os
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from langgraph.graph import LangGraphAgent
from utils.rag_loader import build_rag_index

BASE_DIR = os.path.dirname(__file__)
FRONTEND_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'frontend'))

app = FastAPI(title="Billing Chatbot - LangGraph POC (Option A)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve frontend static files
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

@app.get("/")
async def root():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

agent = LangGraphAgent()

@app.on_event("startup")
async def startup_event():
    try:
        build_rag_index()
        print("RAG index built (or created)." )
    except Exception as e:
        print("Warning: failed to build RAG index on startup:", e)

class ChatRequest(BaseModel):
    user_id: str
    message: str

@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    try:
        result = await agent.handle(req.user_id, req.message)
        # normalize response
        if isinstance(result, dict):
            return result
        return {"answer": str(result)}
    except Exception as e:
        print("ERROR IN CHAT ENDPOINT:", e)
        return JSONResponse(status_code=500, content={"error": str(e)})

class DisputeRequest(BaseModel):
    user_id: str
    issue: str

@app.post("/api/dispute")
async def dispute_endpoint(req: DisputeRequest):
    ticket = await agent.create_dispute(req.user_id, req.issue)
    return ticket

@app.get("/health")
def health():
    return {"status": "ok"}
