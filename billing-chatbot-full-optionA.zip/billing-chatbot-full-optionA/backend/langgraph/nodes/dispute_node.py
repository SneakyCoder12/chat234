import random, json
from pathlib import Path
TICKET_FILE = Path(__file__).parent.parent.parent / 'db' / 'disputes.json'
def create_dispute(user_id, issue):
    if not TICKET_FILE.exists():
        TICKET_FILE.write_text(json.dumps([]))
    tickets = json.loads(TICKET_FILE.read_text())
    ticket = {
        'ticket_id': random.randint(100000, 999999),
        'user_id': user_id,
        'issue': issue,
        'status': 'open'
    }
    tickets.append(ticket)
    TICKET_FILE.write_text(json.dumps(tickets, indent=2))
    return ticket
