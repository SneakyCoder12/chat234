import json
from pathlib import Path
DB = Path(__file__).parent.parent.parent / 'db' / 'billing.json'
def get_usage_for_user(user_id):
    if not DB.exists():
        return None
    data = json.loads(DB.read_text())
    rec = next((r for r in data if r.get('user_id')==str(user_id)), None)
    return rec.get('usage') if rec else None
