import re
from utils.gemini_client import create_chat_completion

async def classify_intent(message):
    msg = message.lower()
    if any(k in msg for k in ['bill', 'charged', 'charge', 'amount', 'invoice', 'overcharge', 'higher this month']):
        return 'BILLING'
    if any(k in msg for k in ['data', 'bundle', 'gb', 'mb', 'renew', 'auto-renew', 'bundle not working', 'roam']):
        return 'USAGE'
    if any(k in msg for k in ['dispute','wrong charge','incorrect','refund','complain']):
        return 'DISPUTE'
    prompt = [
        {'role':'system','content':"Classify the user's intent into one of: BILLING, USAGE, DISPUTE, GENERAL."},
        {'role':'user','content': message}
    ]
    try:
        resp = await create_chat_completion(prompt)
        cl = (resp or '').strip().upper()
        if 'BILL' in cl: return 'BILLING'
        if 'USAGE' in cl: return 'USAGE'
        if 'DISPUTE' in cl: return 'DISPUTE'
    except Exception:
        pass
    return 'GENERAL'
