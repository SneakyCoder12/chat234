from collections import defaultdict
class ConversationMemory:
    def __init__(self):
        self.store = defaultdict(list)
    def append(self, user_id, turn):
        self.store[str(user_id)].append(turn)
        if len(self.store[str(user_id)])>50:
            self.store[str(user_id)] = self.store[str(user_id)][-50:]
    def get(self, user_id):
        return self.store.get(str(user_id), [])
