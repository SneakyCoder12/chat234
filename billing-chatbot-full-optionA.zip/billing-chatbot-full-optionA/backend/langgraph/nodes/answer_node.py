import json
from utils.gemini_client import create_chat_completion

async def generate_answer(user_message, intent=None, docs=None, billing=None, usage=None, memory=None):
    system = "You are a telecom billing assistant. Be concise and helpful. Use provided data if available. If a dispute is required, instruct appropriately."
    ctxt = ''
    if docs:
        for d in docs:
            ctxt += f"\nSource {d['id']}:\n{d['text']}\n"
    if billing:
        ctxt += f"\nBilling record:\n{json.dumps(billing)}\n"
    if usage:
        ctxt += f"\nUsage record:\n{json.dumps(usage)}\n"
    if memory:
        ctxt += f"\nConversation memory:\n{json.dumps(memory[-5:])}\n"

    messages = [
        {'role':'system','content': system},
        {'role':'system','content': f"Context:{ctxt}"},
        {'role':'user','content': user_message}
    ]
    try:
        resp_text = await create_chat_completion(messages)
        return resp_text
    except Exception as e:
        return f"Error generating answer: {e}"
