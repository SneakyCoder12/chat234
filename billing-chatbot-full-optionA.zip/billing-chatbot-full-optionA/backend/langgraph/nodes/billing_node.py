import json
from pathlib import Path
DB = Path(__file__).parent.parent.parent / 'db' / 'billing.json'
def get_billing_for_user(user_id):
    if not DB.exists():
        return None
    data = json.loads(DB.read_text())
    recs = [r for r in data if r.get('user_id')==str(user_id)]
    return recs
