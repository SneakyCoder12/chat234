from utils.embeddings_store import query as es_query
import os

def retrieve_docs(message):
    top_k = int(os.getenv('TOP_K_RAG', '3'))
    docs = es_query(message, top_k=top_k)
    return [{'id': d['id'], 'text': d['text'], 'meta': d.get('meta', {})} for d in docs]
