# Lightweight LangGraph-style orchestrator for POC/demo
from .nodes.classifier import classify_intent
from .nodes.rag_node import retrieve_docs
from .nodes.answer_node import generate_answer
from .nodes.billing_node import get_billing_for_user
from .nodes.usage_node import get_usage_for_user
from .nodes.dispute_node import create_dispute
from .nodes.memory import ConversationMemory

class LangGraphAgent:
    def __init__(self):
        self.memory = ConversationMemory()

    async def handle(self, user_id, message):
        intent = await classify_intent(message)
        user_billing = None
        user_usage = None
        if intent == 'BILLING':
            user_billing = get_billing_for_user(user_id)
        elif intent == 'USAGE':
            user_usage = get_usage_for_user(user_id)

        docs = retrieve_docs(message)
        answer = await generate_answer(message, intent=intent, docs=docs, billing=user_billing, usage=user_usage, memory=self.memory.get(user_id))
        self.memory.append(user_id, {'user': message, 'assistant': answer})
        return {'intent': intent, 'answer': answer}

    async def create_dispute(self, user_id, issue):
        ticket = create_dispute(user_id, issue)
        return ticket
