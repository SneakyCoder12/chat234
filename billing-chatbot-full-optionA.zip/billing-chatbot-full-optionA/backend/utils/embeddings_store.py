import json, os
import numpy as np
from pathlib import Path
from .gemini_client import embed_texts

VSTORE = Path(__file__).parent.parent.parent / 'rag' / 'vectors.json'

def _ensure():
    if not VSTORE.exists():
        VSTORE.parent.mkdir(parents=True, exist_ok=True)
        VSTORE.write_text(json.dumps({'docs': []}))

def index_documents(docs):
    _ensure()
    store = json.loads(VSTORE.read_text())
    texts = [d['text'] for d in docs]
    embs = embed_texts(texts)
    for d, e in zip(docs, embs):
        store['docs'].append({'id': d['id'], 'text': d['text'], 'meta': d.get('meta', {}), 'embedding': e})
    VSTORE.write_text(json.dumps(store, indent=2))

def cosine_sim(a, b):
    a = np.array(a); b = np.array(b)
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

def query(text, top_k=3):
    _ensure()
    store = json.loads(VSTORE.read_text())
    if not store.get('docs'):
        return []
    emb = embed_texts([text])[0]
    scored = []
    for doc in store['docs']:
        score = cosine_sim(emb, doc.get('embedding', []))
        scored.append((score, doc))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [d for s, d in scored[:top_k]]
