from pathlib import Path
from .embeddings_store import index_documents

RAG_DIR = Path(__file__).parent.parent.parent / 'rag'

def build_rag_index():
    docs = []
    for f in RAG_DIR.glob('*.md'):
        docs.append({'id': f.name, 'text': f.read_text(), 'meta': {'source': f.name}})
    if docs:
        index_documents(docs)
