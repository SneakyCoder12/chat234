import os
from dotenv import load_dotenv
load_dotenv()
import google.generativeai as genai
import time

api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_KEY")
if not api_key:
    print("[gemini_client] WARNING: GOOGLE_API_KEY not set; client will run in MOCK mode.")
else:
    genai.configure(api_key=api_key)

def _mock_embedding(text):
    s = sum(ord(c) for c in text[:200])
    vec = [(s % (i+7)) / (i+7) for i in range(128)]
    return vec

def embed_texts(texts, model=None):
    vectors = []
    if not api_key:
        for t in texts:
            vectors.append(_mock_embedding(t))
        return vectors
    out = []
    for t in texts:
        try:
            resp = genai.embed_content(model=model or os.getenv('EMBED_MODEL','text-embedding-004'), content=t)
            if isinstance(resp, dict) and resp.get('embedding') is not None:
                out.append(resp['embedding'])
            elif hasattr(resp, 'embedding'):
                out.append(resp.embedding)
            else:
                out.append(_mock_embedding(t))
        except Exception as e:
            print('[gemini_client] embed error:', e)
            out.append(_mock_embedding(t))
    return out

async def create_chat_completion(messages, model=None):
    if not api_key:
        last = messages[-1]['content'] if messages else ''
        return f"[MOCK GEMINI] (no API key set) I would answer: '{last[:200]}' - set GOOGLE_API_KEY in backend/.env to enable real Gemini."

    # Correct model
    model_name = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    
    model = genai.GenerativeModel(model_name)

    # Combine the chat messages into a single prompt
    prompt = ""
    for msg in messages:
        role = msg["role"].upper()
        content = msg["content"]
        prompt += f"{role}: {content}\n"

    try:
        # Gemini 1.5 correct API
        response = model.generate_content(prompt)

        return response.text or str(response)

    except Exception as e:
        print("[gemini_client] chat error:", e)
        return f"[GEMINI ERROR] {e}"
